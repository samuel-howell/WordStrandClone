import React, { useCallback, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '../store/gameStore';
import useSound from 'use-sound';
import { RefreshCw } from 'lucide-react';

export const GameBoard: React.FC = () => {
  const { letters, selectLetter, submitWord, clearSelection, loadDailyPuzzle } = useGameStore();
  const [playSelect] = useSound('/sounds/select.mp3', { volume: 0.5 });
  const [playSuccess] = useSound('/sounds/success.mp3', { volume: 0.5 });
  const [playError] = useSound('/sounds/error.mp3', { volume: 0.3 });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadDailyPuzzle();
  }, []);

  const handleLetterClick = (row: number, col: number) => {
    selectLetter(row, col);
    playSelect();
  };

  const handleSubmit = useCallback(async () => {
    if (isSubmitting) return;

    const selectedLetters = letters
      .flat()
      .filter(l => l.isSelected)
      .sort((a, b) => a.selectionOrder! - b.selectionOrder!);
    
    if (selectedLetters.length < 3) {
      playError();
      return;
    }

    setIsSubmitting(true);
    
    try {
      const currentWord = selectedLetters.map(l => l.char).join('');
      const initialScore = useGameStore.getState().score;
      
      await submitWord();
      
      const newScore = useGameStore.getState().score;
      
      if (newScore > initialScore) {
        playSuccess();
      } else {
        playError();
      }
    } catch (error) {
      console.error('Error submitting word:', error);
      playError();
    } finally {
      setIsSubmitting(false);
    }
  }, [letters, submitWord, playSuccess, playError, isSubmitting]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    } else if (e.key === 'Escape') {
      clearSelection();
    }
  }, [handleSubmit, clearSelection]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const selectedLetters = letters
    .flat()
    .filter(l => l.isSelected)
    .sort((a, b) => a.selectionOrder! - b.selectionOrder!);
    
  const currentWord = selectedLetters.map(l => l.char).join('');

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-white">Daily Word Puzzle</h2>
        <button
          onClick={loadDailyPuzzle}
          className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          disabled={isSubmitting}
        >
          <RefreshCw className={`w-5 h-5 text-white ${isSubmitting ? 'opacity-50' : ''}`} />
        </button>
      </div>
      
      <div className="grid grid-cols-4 gap-2 p-4 bg-gradient-to-br from-purple-900/20 to-blue-900/20 rounded-lg backdrop-blur-sm">
        {letters.map((row, rowIndex) => (
          <React.Fragment key={rowIndex}>
            {row.map((letter, colIndex) => (
              <motion.button
                key={letter.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`w-16 h-16 rounded-lg flex items-center justify-center text-2xl font-bold 
                  ${
                    letter.isSelected
                      ? 'bg-purple-500 text-white'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  }
                  transition-colors duration-200 ease-in-out relative
                  ${isSubmitting ? 'cursor-not-allowed opacity-50' : ''}`}
                onClick={() => !isSubmitting && handleLetterClick(rowIndex, colIndex)}
                disabled={isSubmitting}
              >
                {letter.char}
                {letter.isSelected && (
                  <span className="absolute top-1 right-1 text-xs bg-white/20 rounded-full w-5 h-5 flex items-center justify-center">
                    {letter.selectionOrder! + 1}
                  </span>
                )}
              </motion.button>
            ))}
          </React.Fragment>
        ))}
      </div>
      
      <AnimatePresence>
        {currentWord && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="flex justify-between items-center p-4 bg-white/10 rounded-lg backdrop-blur-sm"
          >
            <span className="text-2xl font-bold text-white">{currentWord}</span>
            <div className="space-x-2">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={clearSelection}
                className={`px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-white rounded-lg transition-colors
                  ${isSubmitting ? 'cursor-not-allowed opacity-50' : ''}`}
                disabled={isSubmitting}
              >
                Clear
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleSubmit}
                className={`px-4 py-2 bg-green-500/20 hover:bg-green-500/30 text-white rounded-lg transition-colors
                  ${isSubmitting ? 'cursor-not-allowed opacity-50' : ''}`}
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Checking...' : 'Submit'}
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};