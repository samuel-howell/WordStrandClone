export interface Letter {
  id: string;
  char: string;
  isSelected: boolean;
  selectionOrder: number | null;
  position: {
    row: number;
    col: number;
  };
}

export interface GameState {
  letters: Letter[][];
  validWords: string[];
  foundWords: string[];
  score: number;
  isGameOver: boolean;
}