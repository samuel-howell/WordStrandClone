import { create } from "zustand";
import { GameState, Letter } from "../types";

interface DailyPuzzleResponse {
  grid: string[][];
  validWords: string[];
}

// Fallback puzzle data when API is not available
const fallbackPuzzle: DailyPuzzleResponse = {
  grid: [
    ["S", "T", "A", "R"],
    ["P", "L", "E", "N"],
    ["I", "D", "S", "T"],
    ["T", "E", "A", "R"]
  ],
  validWords: [
    "STAR", "TEAR", "EAST", "SENT", "TEND", "DEAR", "READ", "SEND", 
    "SEAT", "NEAT", "TEAM", "SAND", "DARE", "RATE", "EARN", "NEAR",
    "STAND", "STARE", "TEARS", "STEAM", "STERN", "SPARE", "SPEAR"
  ]
};

const validateWordWithDictionary = async (word: string): Promise<boolean> => {
  try {
    const response = await fetch(
      `https://api.dictionaryapi.dev/api/v2/entries/en/${word.toLowerCase()}`
    );
    return response.ok;
  } catch (error) {
    console.warn("Dictionary API error:", error);
    return false;
  }
};

const getLetterFrequency = (word: string): Map<string, number> => {
  const frequency = new Map<string, number>();
  for (const char of word.toUpperCase()) {
    frequency.set(char, (frequency.get(char) || 0) + 1);
  }
  return frequency;
};

const canFormWord = (word: string, grid: Letter[][]): boolean => {
  const gridFrequency = getLetterFrequency(
    grid.flat().map(l => l.char).join('')
  );
  const wordFrequency = getLetterFrequency(word);

  for (const [char, count] of wordFrequency) {
    if ((gridFrequency.get(char) || 0) < count) {
      return false;
    }
  }
  return true;
};

const fetchDailyPuzzle = async (): Promise<DailyPuzzleResponse> => {
  if (!import.meta.env.VITE_OPENAI_API_KEY) {
    console.log("No OpenAI API key found, using fallback puzzle");
    return fallbackPuzzle;
  }

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      console.warn("API request failed, using fallback puzzle");
      return fallbackPuzzle;
    }

    const data = await response.json();
    const puzzleData: DailyPuzzleResponse = JSON.parse(
      data.choices[0].message.content
    );

    return puzzleData;
  } catch (error) {
    console.warn("Error fetching daily puzzle, using fallback puzzle:", error);
    return fallbackPuzzle;
  }
};

const createInitialLetters = (grid: string[][]): Letter[][] => {
  return grid.map((row, rowIndex) =>
    row.map((char, colIndex) => ({
      id: `${rowIndex}-${colIndex}`,
      char,
      isSelected: false,
      selectionOrder: null,
      position: { row: rowIndex, col: colIndex },
    }))
  );
};

const isAdjacent = (
  pos1: { row: number; col: number },
  pos2: { row: number; col: number }
): boolean => {
  const rowDiff = Math.abs(pos1.row - pos2.row);
  const colDiff = Math.abs(pos1.col - pos2.col);
  return rowDiff <= 1 && colDiff <= 1 && !(rowDiff === 0 && colDiff === 0);
};

interface GameStore extends GameState {
  selectLetter: (row: number, col: number) => void;
  submitWord: () => Promise<void>;
  clearSelection: () => void;
  loadDailyPuzzle: () => Promise<void>;
}

export const useGameStore = create<GameStore>((set, get) => ({
  letters: createInitialLetters(fallbackPuzzle.grid),
  validWords: fallbackPuzzle.validWords,
  foundWords: [],
  score: 0,
  isGameOver: false,

  loadDailyPuzzle: async () => {
    try {
      const { grid, validWords } = await fetchDailyPuzzle();
      set({
        letters: createInitialLetters(grid),
        validWords,
        foundWords: [],
        score: 0,
        isGameOver: false,
      });
    } catch (error) {
      console.error("Failed to load daily puzzle:", error);
      set({
        letters: createInitialLetters(fallbackPuzzle.grid),
        validWords: fallbackPuzzle.validWords,
        foundWords: [],
        score: 0,
        isGameOver: false,
      });
    }
  },

  selectLetter: (row: number, col: number) =>
    set((state) => {
      const newLetters = [...state.letters.map((row) => [...row])];
      const letter = newLetters[row][col];

      if (letter.isSelected) {
        const currentOrder = letter.selectionOrder;
        newLetters.forEach((row) =>
          row.forEach((l) => {
            if (
              l.selectionOrder !== null &&
              l.selectionOrder >= currentOrder!
            ) {
              l.isSelected = false;
              l.selectionOrder = null;
            }
          })
        );
        return { letters: newLetters };
      }

      const selectedLetters = newLetters
        .flat()
        .filter((l) => l.isSelected)
        .sort((a, b) => (a.selectionOrder ?? 0) - (b.selectionOrder ?? 0));

      if (
        selectedLetters.length === 0 ||
        (selectedLetters.length > 0 &&
          isAdjacent(selectedLetters[selectedLetters.length - 1].position, {
            row,
            col,
          }))
      ) {
        letter.isSelected = true;
        letter.selectionOrder = selectedLetters.length;
        return { letters: newLetters };
      }

      return state;
    }),

  submitWord: async () => {
    const state = get();
    const selectedLetters = state.letters
      .flat()
      .filter((l) => l.isSelected)
      .sort((a, b) => (a.selectionOrder ?? 0) - (b.selectionOrder ?? 0));

    if (selectedLetters.length < 3) {
      return;
    }

    const word = selectedLetters.map((l) => l.char).join("");
    const newLetters = state.letters.map((row) =>
      row.map((letter) => ({
        ...letter,
        isSelected: false,
        selectionOrder: null,
      }))
    );

    // First check if it's in the predefined valid words list
    if (state.validWords.includes(word) && !state.foundWords.includes(word)) {
      const scoreIncrease = Math.pow(2, word.length - 2) * 10;
      const newFoundWords = [...state.foundWords, word].sort();

      set({
        letters: newLetters,
        foundWords: newFoundWords,
        score: state.score + scoreIncrease,
      });
      return;
    }

    // If not in predefined list, validate with dictionary API
    if (
      !state.foundWords.includes(word) &&
      canFormWord(word, state.letters) &&
      await validateWordWithDictionary(word)
    ) {
      const scoreIncrease = Math.pow(2, word.length - 2) * 10;
      const newFoundWords = [...state.foundWords, word].sort();

      set({
        letters: newLetters,
        foundWords: newFoundWords,
        score: state.score + scoreIncrease,
      });
      return;
    }

    // If word is not valid, just clear the selection
    set({
      letters: newLetters,
    });
  },

  clearSelection: () =>
    set((state) => ({
      letters: state.letters.map((row) =>
        row.map((letter) => ({
          ...letter,
          isSelected: false,
          selectionOrder: null,
        }))
      ),
    })),
}));